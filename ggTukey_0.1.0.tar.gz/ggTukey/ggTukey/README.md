# ggTukey
Creates a visual analogue for Tukey's Range Test
