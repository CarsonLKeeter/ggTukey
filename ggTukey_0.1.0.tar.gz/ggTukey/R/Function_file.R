#' A visual analogue for Tukey's Range Test for numeric factors
#'
#' Use this function if factor elements contain numbers (i.e. day-to-day comparisons; Day1-Day2, Day1-Day3, etc would return 1-2, 1-3, etc)
#'
#' Uses ggplot2 and ggpubr to create a dotplot based on significant pairwise comparisons based on Tukey's Range (aka Tukey's Honest Significant Differences) for numeric factor data.
#'
#' @param tukey_object A TukeyHSD() object saved as a variable
#' @param a.pri Your chosen alpha (conventionally 0.05). It's a good idea to use '1-conf.level'.
#' @return Returns a dotplot with significant differences as black dots and insignificant differences with white dots. This function also returns a list of significant comparisons in the console.
#' @examples
#' my_aov <- aov(outcome ~ group_predictor, data = my_data)
#'
#' my_TukeyHSD <- TukeyHSD(my_aov, conf.level = 0.95, ...)
#'
#' ggTukey(my_TukeyHSD, a.pri = 0.05)
#'
#' @export

ggTukey_num <- function(tukey_object, a.pri){

  require(tidyverse)
  require(ggpubr)

  x <- as.data.frame(tukey_object[1])

  names <- row.names(x)

  y <- x %>%
    mutate(names = names) %>%
    separate(names, sep = "-", into = c("x", "y")) %>%
    mutate(x = parse_number(x),
           y = parse_number(y)) %>%
    mutate(x = as.numeric(x),
           y = as.numeric(y)) %>%
    select(c(contains("adj"), "x", "y")) %>%
    mutate(sig = ifelse(.[[1]] <= a.pri, "A", "B"),
           sig = as.factor(sig))

  plot <- ggplot(
    data = y,
    aes(
      x = x,
      y = y,
      fill = sig
      )
    ) +
    geom_point(
      shape = 21,
      color = "black",
      size = 3
      ) +
    scale_fill_manual(
      values=c("black", "white")
      ) +
    theme_minimal(

    ) +
    theme(
      legend.position = "none"
      ) +
    scale_x_continuous(
      breaks = c(1:1000)
      ) +
    scale_y_continuous(
      breaks = c(1:1000)
      ) +
    labs(
      x = NULL,
      y = NULL
    ) +
    theme(
      panel.border = element_blank(),
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      axis.line = element_line(colour = "black")
      )

  print(plot)

  # Selects significant values and creates dataframe
  sig_data <- y %>%
    filter(.[[1]] <= a.pri)

  sig_data <- sig_data[, -4]

  return(as.data.frame(sig_data))

  }

#' A visual analogue for Tukey's Range Test for character factors only
#'
#' Use this function for factors with character elements only (i.e. Bob-Rob, Tim-Tom, etc)
#'
#' Uses ggplot2 and ggpubr to create a dotplot based on significant groupwise comparisons based on Tukey's Range (aka Tukey's Honest Significant Differences).
#'
#' @param tukey_object A TukeyHSD() object saved as a variable
#' @param a.pri Your chosen alpha (conventionally 0.05). It's a good idea to use '1-conf.level'.
#' @return Dotplot with significant differences as black dots and insignificant differences with white dots. This function also returns a list of significant comparisons in the console.
#' @examples
#' my_aov <- aov(outcome ~ group_predictor, data = my_data)
#'
#' my_TukeyHSD <- TukeyHSD(my_aov, conf.level = 0.95, ...)
#'
#' ggTukey(my_TukeyHSD, a.pri = 0.05)
#'
#' @export

ggTukey_char <- function(tukey_object, a.pri){

  ### Load required libraries
  require(tidyverse)
  require(ggpubr)

  ### Saves THSD object's first index as a dataframe
  x <- as.data.frame(tukey_object[1])

  ### Separates names from THSD object
  factor_names <- row.names(x)

  ### Further manipulation of dataframe
  y <- x %>%
    ### Creates variable from names from THSD rownames
    mutate(names = factor_names) %>%
    ### Separates individual comparisons into x & y columns
    separate(names, sep = "-", into = c("x", "y")) %>%
    ### Keeps only p-value, x and y
    select(c(contains("p.adj"), "x", "y")) %>%
    mutate(sig = as.factor(ifelse(.[[1]] <= a.pri, "A", "B")))

  ### Creates plot pair-wise comparison
  plot <- ggplot(
    data = y,
    aes(
      x = x,
      y = y,
      fill = sig
    )
  ) +
    geom_point(
      ### ggpubr shape number
      shape = 21,
      color = "black",
      size = 3
    ) +
    scale_fill_manual(
      values=c("black", "white")
    ) +
    theme_minimal(

    ) +
    theme(
      legend.position = "none"
    ) +
    labs(
      x = NULL,
      y = NULL
    ) +
    theme(
      panel.border = element_blank(),
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      axis.line = element_line(colour = "black")
    )

  print(plot)

  # Selects significant values and creates dataframe
  sig_data <- y %>%
    filter(.[[1]] <= a.pri)

  sig_data <- sig_data[, -4]

  return(as.data.frame(sig_data))
}



